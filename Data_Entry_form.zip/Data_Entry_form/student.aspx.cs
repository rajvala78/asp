﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Configuration;
public partial class student : System.Web.UI.Page
{
    
    
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["student"].ConnectionString;
        SqlConnection con = new SqlConnection(s);
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select * from std ",con);
        DataTable table = new DataTable();
        //IDataAdapter.Fill(table);
        da.Fill(table);
        GridView1.DataSource = table;
        GridView1.DataBind();
        con.Close();
        img1.Visible = false;
    }
    protected void b1_Click(object sender, EventArgs e)
    {
        string s = ConfigurationManager.ConnectionStrings["student"].ConnectionString;
        SqlConnection con = new SqlConnection(s);
        con.Open();
        string filpath = Server.MapPath("images/");
        string filename = Path.GetFileName(f1.FileName);
        HttpPostedFile hp = f1.PostedFile;
        string ex = Path.GetExtension(filename);
        int size = hp.ContentLength;
        string path2 = "images/" + filename;
        if(f1.HasFile==true)
        {
            f1.SaveAs(filpath + filename);
            
            string r = "insert into std values('" + t1.Text + "','" + t2.Text + "','" + d1.SelectedItem.Value + "','" + d2.SelectedItem.Value + "','" + t5.Text + "','"+t6.Text+"','" + path2.ToString() + "')";
            SqlCommand cmd = new SqlCommand(r, con);
            cmd.ExecuteNonQuery();
            int k = cmd.ExecuteNonQuery();
            if(k>0)
            {
                Response.Write("<scrip>alert('Record Inserted...')</script>");
            }
            else
            {
                Response.Write("<script>alert('Record Not Inserted..')");
            }
            con.Close();
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Label lblid = (Label)row.FindControl("Label1");
        Label lblsname = (Label)row.FindControl("Label2");
        Label lblsclass = (Label)row.FindControl("Label3");
        Label lblsgender = (Label)row.FindControl("Label4");
        Label lblsmobile = (Label)row.FindControl("Label5");
        Label lblsemail = (Label)row.FindControl("Label6");

        System.Web.UI.WebControls.Image img = (System.Web.UI.WebControls.Image)row.FindControl("image1");

        t1.Text = lblid.Text;
        t2.Text = lblsname.Text;
        d1.Text = lblsclass.Text;
        d2.Text = lblsgender.Text;
        t5.Text = lblsmobile.Text;
        t6.Text = lblsemail.Text;
        img1.ImageUrl = img.ImageUrl;
        img1.Visible = true;
       }
}